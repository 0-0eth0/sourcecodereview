export class salesData{
    dealerId:string;
    saleDate:string;
    quantity: string;
  };

  export class qdcdData{
    cd:string;
    partyCode:string;
    qd: string;
    yrMonth: string;
  };
  export class collectionTrend{
    accountReceivable:string;
collectionTarget: string;
dealerId:string;
dsoValue: string;
saleTarget: string;
saleValue: string;
yearMonth:string
  };