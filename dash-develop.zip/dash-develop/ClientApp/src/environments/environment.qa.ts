export const environment = {
    production: true,
    apiURL: "https://qa-dash.dalmiabharat.com",
    apiPATH: "/dalmiabharat-smartd/",
    appName: "DASH",
    appVersion: "1.00",
    idleTimeinMin: 30,
    apiaccessKey:"8a1f32b6-7b40-447e-9a96-a54c073ed536",
};
