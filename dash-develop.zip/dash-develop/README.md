# ClientApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.0.

# Dependency
Chart Version Used ng2-charts@2.3.0 --save 
npm i chart.js@2.9.1

# Setup Notes

To install node modules  
1. cd ClientApp
2. Open Powershell
3. Install NodeTool (if not available)
4. npm install

## Build - QA

Run `ng build --configuration qa` to build the project. The build artifacts will be stored in the `dist/` directory.

## Build - Production

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.


