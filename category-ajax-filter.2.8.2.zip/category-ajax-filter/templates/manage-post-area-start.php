<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
echo "<div id='manage-post-area'>";